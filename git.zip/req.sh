sudo -s
chmod 777 *
sudo apt-get upgrade
sudo apt-get update
sudo apt install nodejs
sudo apt install awscli
sudo apt install golang
bash install.sh